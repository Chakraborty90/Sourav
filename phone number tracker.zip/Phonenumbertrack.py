import phonenumbers
from Secret import NUMBER
from Secret import API_KEY
from phonenumbers import geocoder
from phonenumbers import carrier
from opencage.geocoder import OpenCageGeocode
import folium

# country location
x = phonenumbers.parse(NUMBER)
location = geocoder.description_for_number(x, "en")
print(location)
#operator name
operator_name = phonenumbers.parse(NUMBER)
data = carrier.name_for_number(operator_name, "en")
print(data)
geocoder = OpenCageGeocode(API_KEY)
query = str(location)
result = geocoder.geocode(query)

print(result)

lat = result[0]['geometry']['lat']
lng = result[0]['geometry']['lng']
print(lat,lng)

my_map = folium.Map(location = [lat,lng], zoom_start = 9)
folium.Marker([lat,lng], popup=location).add_to(my_map)

my_map.save("mytracker.html")
